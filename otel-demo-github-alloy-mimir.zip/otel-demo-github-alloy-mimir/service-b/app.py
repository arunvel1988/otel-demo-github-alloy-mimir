import requests, logging
from flask import Flask, jsonify
from opentelemetry import trace, metrics
from opentelemetry.sdk.resources import Resource
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.metrics import MeterProvider
from opentelemetry.sdk.trace.export import BatchSpanProcessor
from opentelemetry.sdk.metrics.export import PeriodicExportingMetricReader
from opentelemetry.sdk._logs import LoggerProvider, LoggingHandler
from opentelemetry.sdk._logs.export import BatchLogRecordProcessor
from opentelemetry.exporter.otlp.proto.grpc.trace_exporter import OTLPSpanExporter
from opentelemetry.exporter.otlp.proto.grpc.metric_exporter import OTLPMetricExporter
from opentelemetry.exporter.otlp.proto.grpc._log_exporter import OTLPLogExporter
from opentelemetry.instrumentation.flask import FlaskInstrumentor
from opentelemetry.instrumentation.requests import RequestsInstrumentor

resource = Resource.create({"service.name": "service-b"})
tp = TracerProvider(resource=resource)
tp.add_span_processor(BatchSpanProcessor(OTLPSpanExporter()))
trace.set_tracer_provider(tp)
tracer = trace.get_tracer(__name__)

metrics.set_meter_provider(MeterProvider(
    metric_readers=[PeriodicExportingMetricReader(OTLPMetricExporter(), export_interval_millis=5000)]
))
meter = metrics.get_meter("service-b")
req_counter = meter.create_counter("requests_total")

logger_provider = LoggerProvider(resource=resource)
log_exporter = OTLPLogExporter(endpoint="http://alloy:4318/v1/logs")
logger_provider.add_log_record_processor(BatchLogRecordProcessor(log_exporter))
logging.getLogger().addHandler(LoggingHandler(level=logging.INFO, logger_provider=logger_provider))
logging.getLogger().setLevel(logging.INFO)

app = Flask(__name__)
FlaskInstrumentor().instrument_app(app, tracer_provider=tp)
RequestsInstrumentor().instrument()

@app.route("/")
def index():
    with tracer.start_as_current_span("service-b-root"):
        resp = requests.get("http://service-c:5000/")
        req_counter.add(1, {"endpoint": "/"})
        logging.info("Service B handled root")
        return jsonify({"from": "B", "c_response": resp.json()})
